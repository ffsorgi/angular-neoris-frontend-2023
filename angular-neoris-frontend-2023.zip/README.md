# 🎨 **Frontend - Turnos Rotativos**

Este proyecto es la parte frontend de la aplicación de **Turnos Rotativos**, desarrollada con **Angular 14.2.11** y gestionada con **Yarn**. La aplicación proporciona una interfaz de usuario para gestionar y visualizar empleados, turnos y conceptos asociados, interactuando con el backend de la API desarrollada en **Spring Boot**.

## 🌟 **Descripción del Proyecto**

El frontend se ha desarrollado utilizando **Angular 14.2.11**, proporcionando una experiencia de usuario fluida para interactuar con el sistema de **Turnos Rotativos**. Los usuarios pueden consultar la lista de empleados, agregar nuevos empleados y gestionar los conceptos de turno disponibles.

### **Características principales:**

1. **Visualización de empleados**: Se muestra una lista de empleados obtenida desde la API.
2. **Formulario para agregar empleados**: Los usuarios pueden agregar nuevos empleados.
3. **Visualización de conceptos**: Los conceptos disponibles para asignar turnos se muestran en la interfaz.
4. **Interacción con la API Backend**: Realiza peticiones HTTP para obtener y modificar datos a través de la API backend en **Spring Boot**.

## 🛠️ **Dependencias**

Este proyecto utiliza **Angular 14.2.11** y **Yarn** para la gestión de dependencias. A continuación, se enumeran las dependencias claves del proyecto:

### **Dependencias:**

- **@angular/ (14.2.0)**: El core de Angular, incluyendo animaciones, formularios, y el enrutador.
- **@popperjs/core (2.11.7)**: Utilizado para mejorar la gestión de los popups.
- **bootstrap (5.2.3)**: Framework de CSS para el diseño responsive y componentes predefinidos.
- **jquery (3.6.4)**: Librería para facilitar la manipulación de DOM.
- **rxjs (~7.5.0)**: Biblioteca para la programación reactiva.
- **normalize.css (8.0.1)**: Estilos base para una apariencia consistente entre navegadores.
- **tslib (2.3.0)**: Soporte para las características de TypeScript.
- **zone.js (~0.11.4)**: Librería utilizada por Angular para gestionar el cambio de zonas.

### **Dependencias de desarrollo:**

- **@angular-devkit/build-angular (14.2.11)**: Herramientas necesarias para construir la aplicación Angular.
- **@angular/cli (~14.2.11)**: Herramienta de línea de comandos para Angular.
- **@angular/compiler-cli (14.2.0)**: Compilador de Angular para la compilación Ahead-of-Time.
- **@types/jasmine (~4.0.0)**: Tipos de Jasmine para pruebas unitarias.
- **jasmine-core (~4.3.0)**: Framework de pruebas unitarias.
- **karma (~6.4.0)**: Herramienta para ejecutar pruebas unitarias en navegadores.
- **karma-chrome-launcher (~3.1.0)**: Lanzador de Karma para ejecutar las pruebas en Google Chrome.
- **karma-coverage (~2.2.0)**: Reportes de cobertura de pruebas en Karma.
- **karma-jasmine (~5.1.0)**: Integración de Karma con Jasmine.
- **karma-jasmine-html-reporter (~2.0.0)**: Reportes HTML de Karma con Jasmine.
- **typescript (~4.7.2)**: Compilador de TypeScript.

## ⚙️ **Estructura del Proyecto**

La estructura del proyecto frontend es la siguiente:


### 📂 **Descripción de las Carpetas**

- **src/app**: Contiene el código fuente de la aplicación.
  - **components**: Componentes reutilizables que representan diferentes partes de la UI, como la lista de empleados o el formulario de empleados.
  - **models**: Contiene los modelos de datos que representan las entidades con las que interactúa la aplicación, como empleados y conceptos.
  - **services**: Servicios que interactúan con la API backend para obtener, crear o eliminar datos.
  - **store**: Si se utiliza una librería de gestión del estado como **NgRx**, esta carpeta contendría la lógica para manejar el estado de la aplicación.
- **assets**: Archivos estáticos como imágenes, fuentes y estilos globales.
- **environments**: Contiene configuraciones específicas para los diferentes entornos (desarrollo, producción).
- **angular.json**: Archivo de configuración principal para el proyecto Angular.
- **yarn.lock**: Registra las versiones exactas de las dependencias instaladas con Yarn para garantizar consistencia en las instalaciones.

## 🚀 **Instalación y Configuración**

### 1. Clonar el repositorio

```bash
git clone https://github.com/tuusuario/turnos-rotativos-frontend.git
cd turnos-rotativos-frontend
